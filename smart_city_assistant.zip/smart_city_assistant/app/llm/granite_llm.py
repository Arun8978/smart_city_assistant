def ask_granite(prompt):
    return f"[AI Response to]: {prompt}"
